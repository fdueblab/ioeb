from collections import Counter
from tqdm import tqdm
import igraph as ig
import pandas as pd
import json

def lzp_debug_print_graph(graph):
    for v in graph.vs:
        print(v.index, v.attributes())
    for e in graph.es:
        print(e.index, e.source, e.target, e.attributes())

def graph_node_zero_construction(path, graph):
    df = pd.read_csv(path)
    if graph is None:
        graph = ig.Graph(directed=True)
    for idx, row in df.iterrows():
        graph.add_vertex()
        if row['label'] == 2.0 or row['label'] == 1.0:
            zero_class_label = "1"
        else:
            zero_class_label = "0"
        graph.vs[graph.vcount()-1]["nodes_class_label"] = zero_class_label
        graph.vs[graph.vcount()-1]["original_id"] = row['node_id']

    labels = Counter(graph.vs["nodes_class_label"])
    # print(labels)
    return graph    

def graph_node_after_construction(path, graph):
    cls = path.split('.')[-2].split('_')[-1]
    df = pd.read_csv(path)

    for idx, row in df.iterrows():
        graph.add_vertex()
        graph.vs[graph.vcount()-1]["nodes_class_label"] = cls
        graph.vs[graph.vcount()-1]["original_id"] = row['node_id']

    labels = Counter(graph.vs["nodes_class_label"])
    # print(labels)
    return graph

def graph_edge_construction(path, graph):
    path = f'./edges_{i}.csv'
    df = pd.read_csv(path)
    vertex_lookup = {(v['nodes_class_label'], v['original_id']): v.index for v in graph.vs}

    for idx, row in df.iterrows():
        dst_vertex_index = vertex_lookup.get((str(i), row['dst_id']))
        src_vertex_index = row['src_id']
        graph.add_edge(src_vertex_index, dst_vertex_index)
        graph.es[graph.ecount()-1]["edge_class_label"] = str(i)

    return graph

def print_edge(vertex):
    incident_edges = graph.incident(graph.vs[vertex], mode=ig.ALL)
    for edge in incident_edges:
        print(graph.es[edge].source, graph.es[edge].target, graph.es[edge]['label'])

# main() function
graph = None

# node construction
graph = graph_node_zero_construction('./nodes_0.csv', graph)
for i in range(2, 18):
    path = f'./nodes_{i}.csv'
    graph = graph_node_after_construction(path, graph)

# edge construction
for i in tqdm(range(2, 18)):
    path = f'./edges_{i}.csv'
    graph = graph_edge_construction(path, graph)

graph.write('./lzp_graph.gml')
breakpoint()