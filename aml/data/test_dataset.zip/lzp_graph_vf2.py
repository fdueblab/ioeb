from collections import Counter
from tqdm import tqdm
import igraph as ig
import pandas as pd
import random
import json

graph = ig.read('./lzp_graph.gml')
incident_edges = graph.incident(graph.vs[0], mode=ig.ALL)
labels = Counter(graph.vs["nodesclasslabel"])

def lzp_debug_print_graph(graph):
    for v in graph.vs:
        print(v.index, v.attributes())
    for e in graph.es:
        print(e.index, e.source, e.target, e.attributes())

def print_edge(vertex):
    incident_edges = graph.incident(graph.vs[vertex], mode=ig.ALL)
    for edge in incident_edges:
        print(graph.es[edge].source, graph.es[edge].target, graph.es[edge]['edgeclasslabel'])

def print_node_type(vertex):
    print(graph.vs[vertex]['nodesclasslabel'])

# print matched subgraph
def print_subgraph(subgraph):
    for vertex_1 in subgraph:
        print(graph.vs[vertex_1].index, graph.vs[vertex_1].attributes())
        for vertex_2 in subgraph:
            if graph.get_eid(vertex_1, vertex_2, error=False) != -1:
                edge_id = graph.get_eid(vertex_1, vertex_2)
                print(edge_id, graph.es[edge_id].source, graph.es[edge_id].target, graph.es[edge_id].attributes())

# vf2 process, get_subisomorphisms_vf2
def node_compat_specific_id_fn(graph, pattern, node1, node2):
    nodesclasslabel1 = int(graph.vs[node1]['nodesclasslabel'])
    nodesclasslabel2 = int(pattern.vs[node2]['nodesclasslabel'])
    id1 = int(graph.vs[node1]['id'])
    id2 = int(pattern.vs[node2]['id'])
    fixed_bool = pattern.vs[node2]['fixed']

    if fixed_bool == "True":
        return (nodesclasslabel1 == nodesclasslabel2) and (id1 == id2)
    else:
        return nodesclasslabel1 in [0, 1] and nodesclasslabel2 in [0, 1]
    
def node_type_equal_fn(graph, pattern, node1, node2):
    return graph.vs[node1]['nodesclasslabel'] == pattern.vs[node2]['nodesclasslabel']

def node_type_equal_whatever_app_fn(graph, pattern, node1, node2):
    nodesclasslabel1 = int(graph.vs[node1]['nodesclasslabel'])
    nodesclasslabel2 = int(pattern.vs[node2]['nodesclasslabel'])
    if nodesclasslabel1 in [0, 1]:
        nodesclasslabel1 = 0
    if nodesclasslabel2 in [0, 1]:
        nodesclasslabel2 = 0
    return nodesclasslabel1 == nodesclasslabel2

def edge_compat_fn(graph, pattern, edge1, edge2):
    return graph.es[edge1]['edgeclasslabel'] == pattern.es[edge2]['edgeclasslabel']

# def node_compat_all_fn(graph, pattern, node1, node2):
#     return pattern.vs[node2]['nodesclasslabel'] != '1'

def one_hop_path_select(graph, vertex1, vertex2):
    path = []
    for vertex in graph.neighborhood(vertex1, order=1, mode=ig.ALL):
        if graph.are_connected(vertex2, vertex):
            path.append(vertex)
            print(vertex, end=', ')
            print_node_type(vertex)
    return path

# specific risk id check
def specific_risk_id_check(graph, specific_type_id, show_edges=False):
    risk_vertexs = []
    type_vertexs = []
    for vertex in range(len(graph.vs)):
        if graph.vs[vertex]['nodesclasslabel'] == '1':
            risk_vertexs.append(vertex)

        if graph.vs[vertex]['nodesclasslabel'] == str(specific_type_id):
            type_vertexs.append(vertex)

    specific_types = []
    seen_risk_set = set()
    for specific_type in type_vertexs:
        for risk1 in risk_vertexs:
            for risk2 in risk_vertexs:
                if risk1 == risk2:
                    continue
                if graph.are_connected(risk1, specific_type) and graph.are_connected(risk2, specific_type):
                    if show_edges:
                        print(risk1, specific_type, risk2)
                    specific_types.append((risk1, specific_type, risk2))
                    seen_risk_set.add(risk1)
                    seen_risk_set.add(risk2)

    print("label:", specific_type_id, ", one-hop:", int(len(specific_types)/2))
    print("label:", specific_type_id, ", length of seen_risk_set", len(seen_risk_set), ", seen_risk_set", seen_risk_set)
    return specific_types

# specific all app id check
def specific_all_app_id_check(graph, specific_type_id):
    risk_vertexs = []
    type_vertexs = []
    for vertex in range(len(graph.vs)):
        if graph.vs[vertex]['nodesclasslabel'] == '1' or graph.vs[vertex]['nodesclasslabel'] == '0':
            risk_vertexs.append(vertex)

        if graph.vs[vertex]['nodesclasslabel'] == str(specific_type_id):
            type_vertexs.append(vertex)

    specific_types = []
    for specific_type in tqdm(type_vertexs):
        for risk1 in risk_vertexs:
            for risk2 in risk_vertexs:
                if risk1 == risk2:
                    continue
                if graph.are_connected(risk1, specific_type) and graph.are_connected(risk2, specific_type):
                    specific_types.append((risk1, specific_type, risk2))
    print("label:", specific_type_id, ", one-hop:", int(len(specific_types)/2))
    return specific_types

def random_walk(graph, start_node, walk_length=6, back_probability=0.5):
    path = [start_node]
    node_set = set()
    current_node = start_node
    last_node = start_node
    
    while len(node_set) < walk_length:
        neighbors = graph.neighbors(current_node)
        if not neighbors:
            break  # Stop if the current node has no neighbors
        current_node = random.choice(neighbors)  # Choose a random neighbor
        # print(current_node)
        if random.random() < back_probability:
            current_node = last_node
        path.append(current_node)
        node_set.add(current_node)
    
    # Create a subgraph based on the nodes visited during the walk
    subgraph = graph.subgraph(path)
    return subgraph

def statistic_func(nodes, times):
    all_recall_isomorphisms = 0
    all_recall_risk_nodes_coverage = 0
    all_recall_rate = 0

    all_precision_isomorphisms = 0
    all_precision_risk_iso = 0
    all_precision_rate = 0
    
    for _ in tqdm(range(times)):
        subgraph = random_walk(graph, 0, nodes)

        # Coverage/Recall rate
        risk_isomorphisms = graph.get_subisomorphisms_vf2(subgraph, node_compat_fn=node_type_equal_fn, edge_compat_fn=edge_compat_fn)
        
        if len(risk_isomorphisms) > 10000000:
            continue
        
        risk_nodes_coverage_set = set()
        for isomorphism in risk_isomorphisms:
            for v_node in isomorphism:
                if graph.vs[v_node]['nodesclasslabel'] == "1":
                    risk_nodes_coverage_set.add(v_node)

        all_recall_isomorphisms += len(risk_isomorphisms)
        all_recall_risk_nodes_coverage += len(risk_nodes_coverage_set)
        all_recall_rate += round(len(risk_nodes_coverage_set)/35, 2)

        # Precision rate
        risk_isomorphisms = graph.get_subisomorphisms_vf2(subgraph, node_compat_fn=node_type_equal_whatever_app_fn, edge_compat_fn=edge_compat_fn)
        
        if len(risk_isomorphisms) > 10000000:
            continue
        
        num_risk_iso = 0
        for isomorphism in risk_isomorphisms:
            for v_node in isomorphism:
                if graph.vs[v_node]['nodesclasslabel'] == "1":
                    num_risk_iso += 1
                    continue

        all_precision_isomorphisms += len(risk_isomorphisms)
        all_precision_risk_iso += num_risk_iso
        all_precision_rate += round(num_risk_iso/len(risk_isomorphisms), 3)

    all_recall_isomorphisms /= times
    all_recall_risk_nodes_coverage /= times
    all_recall_rate /= times

    all_precision_isomorphisms /= times
    all_precision_risk_iso /= times
    all_precision_rate /= times

    all_f1_score = 2 * all_precision_rate * all_recall_rate / (all_precision_rate + all_recall_rate)

    print("匹配子图数量: ", all_recall_isomorphisms)
    print("覆盖风险节点: ", all_recall_risk_nodes_coverage)
    print("召回率: ", all_recall_rate)

    print("匹配子图数量: ", all_precision_isomorphisms)
    print("风险子图数量: ", all_precision_risk_iso)
    print("精确率: ", all_precision_rate)

    print("F1值: ", all_f1_score)
    return (all_recall_isomorphisms, all_recall_risk_nodes_coverage, all_recall_rate, all_precision_isomorphisms, all_precision_risk_iso, all_precision_rate)

if __name__ == "__main__":
    results = statistic_func(8, 1)
    breakpoint()
